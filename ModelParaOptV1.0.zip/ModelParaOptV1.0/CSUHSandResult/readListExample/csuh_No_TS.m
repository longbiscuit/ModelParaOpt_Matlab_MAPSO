% 2. myType=: 1��������ˮCU��2������p��3����Χѹ����CD����sigma3����4��������K0ѹ��, 5.����ѹ��ISO��6.���ص������쳤, 7.��sigma1·��
%% initial
clear all;clc;
close all;

%% 1. basic parameters of CSUH, initial state and other informations
% Toyoura sand 
PARAx=[1.25 0.3 0.04 0.135 1.973 0 0.934 0.4 1.8];
myType=3;% Test type: CD
sc=[100];% initial confine pressure(also the p0): sig30
e0=[0.831];%
totlee1=0.15;
num=3000;
filename = 'Toyoura sand under CD test.xlsx';

%% compute process
M=PARAx(1);landa=PARAx(4);kapa=PARAx(3);v=PARAx(2);N=PARAx(5);x=PARAx(8);m=PARAx(9);Z=PARAx(7);
if(m>(1-x)/((1+x)*(landa-kapa)))
    disp('error������ m is too large!');
    return;
end
if(x<0 || x>=1)
     disp('error��');
         return;
end
% delte1=[0.0,0.001,0.001,0.002,0.003,0.004,0.005,0.006,0.006,0.006,0.006,0.011,0.017,0.018,0.019,0.020,0.03,0.04];%
delte1=totlee1/(num)*ones(1,num);%��1���� epsilon1��ѹ��Ϊ��������Ϊ��
de1=delte1;
num=numel(delte1);
writeLoc=round(linspace(1,num,num));


[~,number]=size(de1);%epsilon1 ����
S1=zeros(1,number);%��Ӧ�� ��1
S2=zeros(1,number);
S3=zeros(1,number);
S11=zeros(1,number);% �任Ӧ���ռ���Ӧ�� ��1
S22=zeros(1,number);
S33=zeros(1,number);
p=zeros(1,number); %�任Ӧ���ռ�ƽ��Ӧ��p
q=zeros(1,number);
qz=zeros(1,number);%��ʵӦ���ռ�����Ӧ��q
pz=zeros(1,number);
e1=zeros(1,number);%��1
e2=zeros(1,number);
e3=zeros(1,number);
ev=zeros(1,number);%�ܵ�����v
evp=zeros(1,number);%�������Ӧ���v
ed=zeros(1,number);%��d ����Ӧ��
n=zeros(1,number);%Ӧ����yita
nz=zeros(1,number);%��ʵӦ���ռ�Ӧ����yita
e=zeros(1,number);%��϶��
E=zeros(1,number);%����ģ��
u=zeros(1,number);%��ѹ
kesi=zeros(1,number);
Mf=zeros(1,number);
Mc=zeros(1,number);
Oute1=zeros(1,number);
Outq=zeros(1,number);
Outev=zeros(1,number);
Outpz=zeros(1,number);
Oute=zeros(1,number);
Outu=zeros(1,number);
px=zeros(1,number);%��������p���Ҳཻ��
py=zeros(1,number);%����������p���Ҳཻ��

epnum=zeros(1,number);
scAlf=sprintfc('%g',sc);%����������ת�����ַ�������
scNum=length(sc);
% ����Χѹѭ��
for im=1:scNum
    sheet = im;
    S1(1)=sc(im);
    S2(1)=sc(im);
    S3(1)=sc(im);%
    e(1)=e0(im);%��ʼ��϶��
    ck=kapa/(1+e0(im));
    cp=(landa-kapa)/(1+e0(im));
    three='abcdefghijklmn';
    ps=exp((N-Z)/landa)-1;
    for in=1:number
        
        I1=S1(in)+S2(in)+S3(in);%S1��ʵӦ����Ӧ��sig1  I1��ʵӦ���ռ��е�һӦ��������
        I2=S1(in)*S2(in)+S2(in)*S3(in)+S3(in)*S1(in);
        I3=S1(in)*S2(in)*S3(in);%û�м�Ӧ�������
        
        p(in)=I1/3;%�任Ӧ���ռ���p
        pz(in)=p(in);
        q(in)=1/sqrt(2)*sqrt((S1(in)-S2(in))^2+(S2(in)-S3(in))^2+(S1(in)-S3(in))^2);%��ʵӦ���ռ�����Ӧ��
        qz(in)=q(in);
        
        n(in)=q(in)/p(in);
        kesi(in)=Z-landa*log((p(in)+ps)/(1+ps))-(landa-kapa)*log(((1+(1+x)*n(in)^2/(M^2-x*n(in)^2))*p(in)+ps)/(p(in)+ps))-e(in);%��Щ���������ڱ任Ӧ���ռ�����
        Mf(in)=6*(sqrt(12*(3-M)/M^2*exp(-kesi(in)/(landa-kapa))+1)+1)^(-1);
        Mc(in)=M*exp(-m*kesi(in));
        
        dpdS1=1/3;dpdS2=1/3;dpdS3=1/3;
        dqdS1=(2*S1(in)-S2(in)-S3(in))/(2*q(in));
        dqdS2=(2*S2(in)-S1(in)-S3(in))/(2*q(in));
        dqdS3=(2*S3(in)-S1(in)-S2(in))/(2*q(in));
        
        dfdp=(M^4-(1+3*x)*M^2*n(in)^2-x*n(in)^4)/(p(in)*(M^2-x*n(in)^2)*(M^2+n(in)^2+(M^2-x*n(in)^2)*ps/p(in)));%�������ƺõĹ�ʽ
        dfdq=2*M^2*(1+x)*n(in)/(p(in)*(M^2-x*n(in)^2)*(M^2+n(in)^2+(M^2-x*n(in)^2)*ps/p(in)));
        
         dfdS1=dfdp*dpdS1+dfdq*dqdS1;
        dfdS2=dfdp*dpdS2+dfdq*dqdS2;
        dfdS3=dfdp*dpdS3+dfdq*dqdS3;
        
        dgdp=(Mc(in)^2-n(in)^2)/(p(in)*(Mc(in)^2+n(in)^2));%g�Ǳ任Ӧ���ռ���
        dgdq=2*n(in)/(p(in)*(Mc(in)^2+n(in)^2));
        
        dpdS11=1/3;dpdS22=1/3;dpdS33=1/3;
        dqdS11=(2*S1(in)-S2(in)-S3(in))/(2*q(in));%���q�Ǳ任Ӧ�����򵥵��Ƶ�
        dqdS22=(2*S2(in)-S1(in)-S3(in))/(2*q(in));
        dqdS33=(2*S3(in)-S1(in)-S2(in))/(2*q(in));
        
        dgdS11=dgdp*dpdS11+dgdq*dqdS11;
        dgdS22=dgdp*dpdS22+dgdq*dqdS22;
        dgdS33=dgdp*dpdS33+dgdq*dqdS33;

        E=3*(1-2*v)*(p(in)+ps)/ck;
        C11=1/E;
        C12=-v/E;
        C13=-v/E;
        C21=-v/E;
        C22=1/E;
        C23=-v/E;
        C31=-v/E;
        C32=-v/E;
        C33=1/E;% ������Ⱦ��� Ce
        %�ж�������ʵ��
        switch myType
            case 1% CU
                dS1=de1(in)/(C11-(C11+C21+C31)*(C12+C13)/(C13+C23+C33+C12+C22+C32));
                dS3=-(C11+C21+C31)*dS1/(C13+C23+C33+C12+C22+C32);
                dS2=dS3;
                de2=(C21)*dS1+(C22+C23)*dS3;
                de3=(C31)*dS1+(C32+C33)*dS3;
                
            case 2% Constant p
                dS1=(-2)*de1(in)/(-2*C11+C12+C13);
                dS2=(-1)*de1(in)/(2*C11-C12-C13);
                dS3=(1)*de1(in)/(-2*C11+C12+C13);
                de2=C21*dS1-C22*dS1-C22*dS3+C23*dS3;
                de3=C31*dS1-C32*dS1-C32*dS3+C33*dS3;

            case 3% CD
                dS1=de1(in)/(C11);
                dS2=0;
                dS3=0;
                de2=(C21)*dS1;
                de3=(C31)*dS1;
                
            case 4 % k0
                dS1=(C22 + C23)* de1(in)/(  - C13* C21 + C11* C22  + C11 *C23 -C12 *C21 );
                dS2=(-C21  )*de1(in)/(  - C13*C21 + C11*C22   + C11*C23 -C12*C21 );
                dS3=(C21 )* de1(in)/(  C13*C21 - C11*C22   - C11*C23 +C12*C21);
                de2=0;
                de3=0;
                
            case 5 % Isotropic compression
                dS1=de1(in)/(C11+C12+C13);
                dS2=dS1;
                dS3=dS1;
                de2=(C21+C22+C23)*dS1;
                de3=(C31+C32+C33)*dS1;
                
            otherwise
                disp('there is no that kind of stress path!')
                return;
                
        end
        
        
        
        if( dfdS1*dS1+dfdS2*dS2+dfdS3*dS3>0 || ...
                (dfdS1*dS1+dfdS2*dS2+dfdS3*dS3<=0 && Mf(in)<=n(in) ) ...
                )%  ��Ӧ����õ��� ��ѹ�������쳤���õ��ϣ���ʱde1<0,dF<0������Ӧ�õ����Ծ���
            %         if( dfdS1*dS1+dfdS2*dS2+dfdS3*dS3>0  )
            A=cp*(Mc(in)^4-n(in)^4)/(Mf(in)^4-n(in)^4);% CSUH  %A=cp*(Mc(in)^4*p(in)^4-q(in)^4)/(Mf(in)^4*p(in)^4-q(in)^4);%������
            %      CSUH���˻���
            %      ͨ������=0�Ϳ����˻���UH��
            %           A=cp;%�˻�ΪMCCģ�ͣ�
            epnum(in)=1;%�����ԵĴ���
            %------------------------------------------------------
            C11=1/E+A*dfdS1*dgdS11/dgdp;
            C12=-v/E+A*dfdS2*dgdS11/dgdp;
            C13=-v/E+A*dfdS3*dgdS11/dgdp;
            C21=-v/E+A*dfdS1*dgdS22/dgdp;
            C22=1/E+A*dfdS2*dgdS22/dgdp;
            C23=-v/E+A*dfdS3*dgdS22/dgdp;
            C31=-v/E+A*dfdS1*dgdS33/dgdp;
            C32=-v/E+A*dfdS2*dgdS33/dgdp;
            C33=1/E+A*dfdS3*dgdS33/dgdp;% ��������Ⱦ���Cep
            %�ж�������ʵ��
            switch myType
                           case 1% CU
                dS1=de1(in)/(C11-(C11+C21+C31)*(C12+C13)/(C13+C23+C33+C12+C22+C32));
                dS3=-(C11+C21+C31)*dS1/(C13+C23+C33+C12+C22+C32);
                dS2=dS3;
                de2=(C21)*dS1+(C22+C23)*dS3;
                de3=(C31)*dS1+(C32+C33)*dS3;
                
            case 2% Constant p
                dS1=(-2)*de1(in)/(-2*C11+C12+C13);
                dS2=(-1)*de1(in)/(2*C11-C12-C13);
                dS3=(1)*de1(in)/(-2*C11+C12+C13);
                de2=C21*dS1-C22*dS1-C22*dS3+C23*dS3;
                de3=C31*dS1-C32*dS1-C32*dS3+C33*dS3;

            case 3% CD
                dS1=de1(in)/(C11);
                dS2=0;
                dS3=0;
                de2=(C21)*dS1;
                de3=(C31)*dS1;
                
            case 4 % k0
                dS1=(C22 + C23)* de1(in)/(  - C13* C21 + C11* C22  + C11 *C23 -C12 *C21 );
                dS2=(-C21  )*de1(in)/(  - C13*C21 + C11*C22   + C11*C23 -C12*C21 );
                dS3=(C21 )* de1(in)/(  C13*C21 - C11*C22   - C11*C23 +C12*C21);
                de2=0;
                de3=0;
                
            case 5 % Isotropic compression
                dS1=de1(in)/(C11+C12+C13);
                dS2=dS1;
                dS3=dS1;
                de2=(C21+C22+C23)*dS1;
                de3=(C31+C32+C33)*dS1;
                
                otherwise
                    disp('there is no that kind of stress path!')
                    return;
            end
        end
        S1(in+1)=S1(in)+dS1;
        S2(in+1)=S2(in)+dS2;
        S3(in+1)=S3(in)+dS3;
        
        %ƽ��Ӧ��
        %     S2(in+1)=sqrt(S1(in+1)*S3(in+1));
        
        e1(in+1)=e1(in)+de1(in);
        e2(in+1)=e2(in)+de2;
        e3(in+1)=e3(in)+de3;
        ev(in+1)=e1(in+1)+e2(in+1)+e3(in+1);
        ed(in+1)=sqrt(2)/3*sqrt((e1(in+1)-e2(in+1))^2+(e1(in+1)-e3(in+1))^2+(e3(in+1)-e2(in+1))^2);
        e(in+1)=e0(im)-ev(in+1)*(1+e0(im));%��϶��
        pz(in+1)=pz(in)+(dS1+dS2+dS3)/3.0;
        qz(in+1)=1/sqrt(2)*sqrt((S1(in+1)-S2(in+1))^2+(S2(in+1)-S3(in+1))^2+(S1(in+1)-S3(in+1))^2);
        
        
        
        if myType==1% ֻ�в���ˮ���п�ѹ�����඼����ˮ���飬��ˮ��û�п�ѹ
            %u(in+1)=S3(1)-S3(in+1);
            % or
            u(in+1)=(1.0/sqrt(2.0)*...
                sqrt((S1(in+1)-S2(in+1))^2+(S2(in+1)-S3(in+1))^2+(S1(in+1)-S3(in+1))^2))/3.0+...
                sc(im)-(S1(in+1)+S2(in+1)+S3(in+1))/3.0;
        end
        
         % table output
%         filename2='Table.xlsx';
%          titou= {'de1','e','p','q','kesi','Mf','Mc','C11','C21','C31','dS1','de3','dev','ev','e1','sig1'};
%          xlswrite(filename2,titou,sheet,'B1')
%          multiN=1;%
%          xlswrite(filename2,(de1(in)*multiN),sheet,['B' num2str(in+1)]);
%          xlswrite(filename2,(e(in+1)),sheet,['C' num2str(in+1)]);
%          xlswrite(filename2,(pz(in+1)),sheet,['D' num2str(in+1)]);
%          xlswrite(filename2,(qz(in+1)),sheet,['E' num2str(in+1)]);
%          xlswrite(filename2,(kesi(in)),sheet,['F' num2str(in+1)]);
%          xlswrite(filename2,(Mf(in)),sheet,['G' num2str(in+1)]);
%          xlswrite(filename2,(Mc(in)),sheet,['H' num2str(in+1)]);
%          xlswrite(filename2,(C11),sheet,['I' num2str(in+1)]);
%          xlswrite(filename2,(C21),sheet,['J' num2str(in+1)]);
%          xlswrite(filename2,(C31),sheet,['K' num2str(in+1)]);
%          xlswrite(filename2,(dS1),sheet,['L' num2str(in+1)]);
%          xlswrite(filename2,(de3*multiN),sheet,['M' num2str(in+1)]);
%          xlswrite(filename2,((de1(in)+de2+de3)*multiN),sheet,['N' num2str(in+1)]);
%          xlswrite(filename2,(ev(in+1)*multiN),sheet,['O' num2str(in+1)]);
%          xlswrite(filename2,(e1(in+1)*multiN),sheet,['P' num2str(in+1)]);
%          xlswrite(filename2,(S1(in+1)),sheet,['Q' num2str(in+1)]);
       
    end

    color=[1 0 0;0 1 0;0 0 1;0.5 0.1 0;0 0.3 0.4;0.6 0.7 0.2;0.5 0.8 0.9;0 0.2 0.1;0.5 0.5 0.5];
    
    subplot(3, 2,1)%e1-q
    h1=plot((e1(1:number)*100)',(qz(1:number))','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('q/kPa');title('e1-q');grid on;hold on;%e1-q

    subplot(3, 2,2)%p-q
    h2=plot((e1(1:number)*100)',(nz(1:number))','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('eta');title('e1-eta');grid on;hold on;%pz-qz
    
    subplot(3, 2,3)%e1-e
    h3=plot((e1(1:number)*100)',(ev(1:number)*100)','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('��v %');title('��1-��v');grid on;hold on;
    
    subplot(3, 2,4)%lnp-e  log(X) returns the natural logarithm ln(x) of each element in array X.
    h4=semilogx((pz(1:number))',(e(1:number))','color',color(im,:),'LineWidth',2);...
        xlabel('lnp/kPa'),ylabel('e');title('lnp-e');grid on;hold on;%e1-q
    h4=semilogx((pz(1))',(e(1))','color',color(im,:),'LineWidth',6,'Marker','*');hold on;
    h4=semilogx((pz(end))',(e(end))','color',color(im,:),'LineWidth',4,'Marker','p');hold on;
    
    if im==1
        %����CSUH��csl������
        % M=PARAx(1);landa=PARAx(4);kapa=PARAx(3);v=PARAx(2);N=PARAx(5);x=PARAx(8);m=PARAx(9);Zc=PARAx(7);Ze=PARAx(7);
        %         CSLPara=[PARAx(1:5) 0 PARAx(6:9)];% 1-M 2-v 3-kappa 4-lambda 5-N 6-C 7-Z 8-chi 9-m
        CSLPara=PARAx;
        %                  CSLpX=0*min(sc):1:50*max(sc);
        %         CSLpX=linspace(0,10*max(sc),number);
        CSLpX=0:1:63139;
        CSUHPs=exp((CSLPara(5)-CSLPara(7))/CSLPara(4))-1;% ps=exp((N-Z)/lambda)-1
        CSLeY=CSLPara(7)-CSLPara(4)*log((CSLpX+CSUHPs)./(1+CSUHPs))-...
            (CSLPara(4)-CSLPara(3))*log(((2.0/(1.0-CSLPara(8)))*CSLpX+CSUHPs)./(CSLpX+CSUHPs));
        
        CSLgtzIndex=CSLeY>0;
        CSLpX=CSLpX(CSLgtzIndex);
        CSLeY=CSLeY(CSLgtzIndex);
        
        %CSUH��NCL
        %         NCLpX=0*min(sc):1:50*max(sc);
        NCLpX=CSLpX;
        NCLeY=CSLPara(7)-CSLPara(4)*log((NCLpX+CSUHPs)./(1+CSUHPs));
        NCLgtzIndex=NCLeY>0;
        NCLpX=NCLpX(NCLgtzIndex);
        NCLeY=NCLeY(NCLgtzIndex);
        
        h4=semilogx(NCLpX,NCLeY,'b-','LineWidth',2);hold on;
        h4=semilogx(CSLpX,CSLeY,'r-','LineWidth',2);hold on;
        
    end
    
    
    subplot(3, 2,5)%e1-u
    h5=plot((e1(1:number)*100)',(u(1:number))','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('u/kPa');title('��1-u');grid on;hold on;%e1-q
    
    subplot(3, 2,6)%e1-e
    h6=plot((e1(1:number)*100)',(e(1:number))','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('e');title('��1-e');grid on;hold on;%e1-q
    
    
    %         %     %ÿ���������excel
    %     titou= {'e1','Matlab-q','Matlab-p','Matlab-e','Matlab-u','ed','Mf','yita','kesi','Mc','ev','e2','e3','S1/S3','S1','S2','S3','px','py','NCLCSLp','NCLe','CSLe'};
    %     xlswrite(filename,titou,sheet,'B1')
    %     multiN=1;%100:�ٷ�����ʽ��1��С����ʽ
    %     xlswrite(filename,(e1(writeLoc)*multiN)',sheet,'B2')
    %     xlswrite(filename,(qz(writeLoc))',sheet,'C2')
    %     xlswrite(filename,(pz(writeLoc))',sheet,'D2')
    %     xlswrite(filename,(ev(writeLoc))',sheet,'E2')
    %     xlswrite(filename,(u(writeLoc))',sheet,'F2')
    %     xlswrite(filename,(ed(writeLoc)*multiN)',sheet,'G2')
    %     xlswrite(filename,(Mf(writeLoc))',sheet,'H2')
    %     xlswrite(filename,(nz(writeLoc))',sheet,'I2')
    %     xlswrite(filename,(kesi(writeLoc))',sheet,'J2')
    %     xlswrite(filename,(Mc(writeLoc))',sheet,'K2')
    %     xlswrite(filename,(ev(writeLoc)*multiN)',sheet,'L2')
    %     xlswrite(filename,(e2(writeLoc)*multiN)',sheet,'M2')
    %     xlswrite(filename,(e3(writeLoc)*multiN)',sheet,'N2')
    %     xlswrite(filename,(S1(writeLoc)./S3(writeLoc))',sheet,'O2')
    %     xlswrite(filename,(S1(writeLoc))',sheet,'P2')
    %     xlswrite(filename,(S2(writeLoc))',sheet,'Q2')
    %     xlswrite(filename,(S3(writeLoc))',sheet,'R2')
    %     xlswrite(filename,(px(writeLoc))',sheet,'S2')
    %     xlswrite(filename,(py(writeLoc))',sheet,'T2')
    %
    %     xlswrite(filename,(NCLpX)',sheet,'U2')
    %     xlswrite(filename,(NCLeY)',sheet,'V2')
    %     xlswrite(filename,(CSLeY)',sheet,'W2')
    
    switch myType
        case 1
            % % %��ʯ cu
            titou= {'e1','Matlab-q','Matlab-p','Matlab-e','Matlab-u','ed','Mf','yita','kesi','Mc','ev','e2','e3','S1/S3','S1','S2','S3','px','py','NCLCSLp','NCLe','CSLe'};
            xlswrite(filename,titou,sheet,'B1')
            multiN=1;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(writeLoc)*multiN)',sheet,'B2')
            xlswrite(filename,(qz(writeLoc))',sheet,'C2')
            xlswrite(filename,(pz(writeLoc))',sheet,'D2')
            xlswrite(filename,(e(writeLoc))',sheet,'E2')
            xlswrite(filename,(u(writeLoc))',sheet,'F2')
        case 3
            %��ʯ cD
            titou= {'e1%','Matlab-q','Matlab-p','Matlab-ev%','Matlab-u','ed','Mf','yita','kesi','Mc','ev','e2','e3','S1/S3','S1','S2','S3','px','py','NCLCSLp','NCLe','CSLe'};
            xlswrite(filename,titou,sheet,'B1')
            multiN=1;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(writeLoc)*multiN)',sheet,'B2')
            xlswrite(filename,(qz(writeLoc))',sheet,'C2')
            xlswrite(filename,(pz(writeLoc))',sheet,'D2')
            xlswrite(filename,(ev(writeLoc)*multiN)',sheet,'E2')
            xlswrite(filename,(u(writeLoc))',sheet,'F2')
            
            
            
        case 5
            %��ʯ ISO
            titou= {'e1','Matlab-q','Matlab-p','Matlab-ev','Matlab-u','ed','Mf','yita','kesi','Mc','ev','e2','e3','S1/S3','S1','S2','S3','px','py','NCLCSLp','NCLe','CSLe'};
            xlswrite(filename,titou,sheet,'B1')
            multiN=1;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(writeLoc)*multiN)',sheet,'B2')
            xlswrite(filename,(qz(writeLoc))',sheet,'C2')
            xlswrite(filename,(pz(writeLoc))',sheet,'D2')
            xlswrite(filename,(ev(writeLoc)*multiN)',sheet,'E2')
            xlswrite(filename,(u(writeLoc))',sheet,'F2')
    end
end


%�ж�������ʵ��
if myType==1
    % %     ʦ�����᲻��ˮ����ͬ��b��
    suptitle('����ˮ�����������CU');
elseif myType==2
    %�ҵĵ�p
    suptitle('��p�����������');
elseif myType==3
    %�ҵ�Χѹ����
    suptitle('Χѹ���������������CD');
elseif myType==4
    %����ѹ��
    suptitle('����ѹ������K0');
elseif myType==5
    suptitle('����ѹ������Iso.');
end

legend(scAlf,'Location','northoutside','Orientation','horizontal');%��ͼ��
disp('success');