clc
clear all;
close all;
diary on % Open log to record all command window commands and output
disp('------------------------------------------------------------------');
disp('project: SOIL'); % You can rename it according to your needs
%% Adjust the current working directory and add some paths as search paths
disp(datetime); % Output the project name to the command window
tic; % From now on time
% dbstop if error % Convenient debugging
format short; % Outputs long/short format numbers in the command window
fclose('all'); % Close all open text documents
filep = mfilename('fullpath'); % filep contains the path to the m file and the file name (without the.m suffix)
[pathstr,namestr]=fileparts(filep);%pathstr is the path of the m file
cd(pathstr); % Switch the current path to the pathstr path as work path
%%% define global variable
global constitiveModel;
global BestSol;
global iterGbestval;
global ErrorType;%0-RRS;1-normalized RRS by current measured data;2-normalized RRS by maximum measured data in this curve;3-MRE. Only the CSUH model completes the selection of different error functions, and the rest are the default RRS normalized by the maximum value.
BestSol.Position=[];
BestSol.Cost=[];
%%% Add folders to search path
addpath(pathstr); % Add  current path to search path

addpath([pathstr '\MCCResult']);%MCCResult is the folder to save the optimization result of MCC constitutive model (suitable for normally consolidated clay)

% Optimize the CSUH model parameters of clays (with the constraint that parameter Z is equal to parameter N),
% By setting parameters (Z=N, Chi=0 and m=0), the CSUH model can be degenerated into UH model
addpath([pathstr '\CSUHClayResult']); % ... the CSUH model (suitable for overconsolidated clay)

addpath([pathstr '\CSUHSandResult']); % ... the CSUH model (suitable for granular materials include sands, rockfills, slags and so on)

addpath([pathstr '\EBResult']); % ... the Duncan-Chang EB model (suitable for granular materials)

% Firstly, the parameters are determined by the definition method, and then the parameters are optimized within the 20% fluctuation range
addpath([pathstr '\EBDefOptResult']); % ... the Duncan-Chang EB model (suitable for granular materials)

addpath([pathstr '\GCLResult']); % ... the grain crushing model of Liu Enlong(suitable for granular materials)

addpath([pathstr '\SSHResult']); % ...the subloading surface model of Hashiguchi (suitable for clay here)

addpath([pathstr '\userDefineResult']); % ...Take the CSUHSand model as an example
res =savepath;
%%  Settings before optimization
%%1- is automatic optimization ?
% autoOpt=0 means no automatic optimization but only compute one generation to output picture. if you know the parameter, you can use this to plot picture��
% autoOpt=1 means automatic optimization using MAPSO  algorithms and output picture;
autoOpt=0;
%%2- Error type
ErrorType=3 %0-RRS;1-��һ����RRS;2-�����ֵ��һ����RRS;3-MRE
%%3- Selection of constitutive model
%1-MCCResult : Modified Cam-clay (MCC) model to describe NC clays
%2-CSUHClayResult: Unified harding model for clays and sands (CSUH model) to describe OC clay
%3-CSUHSandResult: CSUH model to describe sand
%4-EBResult: EB model  to describe sand
%5-EBDefOptResult: EB model  to describe sand,
%6-GCLResult: Grain crushing model of Liu Enlong to describe sand
%7-SSHResult: Subloading surface model  to describe caly
%100-userDefine: Take the CSUHSand model for example
constitiveModel=3;
switch constitiveModel
    case 1%MCCResult
        diary('.\MCCResult\Log.DAT');% Print the log and save it
        disp('Iteration Number and M,��,��,��,N,C of MCC model as follows:');
        nVar=6; % Number of parameters
        VarSize=[1 nVar];   % Decision Variables Matrix Size
        %         VarMin=[0.6,   0.05,  0.002,    0.02,    0.17,     0.0]; % The lower boundary of each parameter
        %         VarMax=[1.8,   0.45,  0.100,    0.40,    3.00,     0.0]; % The upper boundary of each parameter
        % The upper and lower boundary values are equal to observe the calculation effect of parameters
        VarMin=[1.2,   0.25,  0.009,    0.06,    0.752,    0.0]; % The lower boundary of each parameter
        VarMax=[1.2,   0.25,  0.009,    0.06,    0.752,    0.0];% The upper boundary of each parameter
        NumRDP=[ 3,      3,     3,       3,      3,      3]; % Decimal digits
        fhd= str2func('MCCCallMex');%Set error function; Format of test data input : ��1,q,p',��v,u
    case 2 % CSUHClayResult
        diary('.\CSUHClayResult\Log.DAT');
        disp('Iteration Number and M,��,��,��,N,C,Z,��,m of CSUH model (for clays) as follows:');
        nVar=9;% Number of parameters
        VarSize=[1 nVar];   % Parameter Matrix Size
        VarMin=[0.8,   0.05,  0.002,    0.02,    0.17,    0.0,   0.17,   0.00,  0.0] %The lower boundary of each parameter
        VarMax=[1.8,   0.45,  0.100,    0.40,    3.00,     0.0,   1.50,   0.99,  15.0] %The upper boundary of each parameter
        % The upper and lower boundary values are equal to observe the calculation effect of parameters
        %             VarMin=[1.235	0.449	0.004	0.059	0.745	0	0.745	0.229	11.406] %The lower boundary of each parameter
        %              VarMax=[1.235	0.449	0.004	0.059	0.745	0	0.745	0.229	11.406] %The upper boundary of each parameter
        
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3,     3]; %ones(1,nVar)*3, Decimal digits
        fhd= str2func('CSUHClayCallMex');
    case 3 % CSUHSandResult
        diary('.\CSUHSandResult\Log.DAT');
        disp('Iteration Number and M,��,��,��,N,C,Z,��,m of CSUH model (for sands) as follows:');
        nVar=9;% Number of parameters
        VarSize=[1 nVar];% Parameter Matrix Size
        %             VarMin=[0.8,0.05,0.002,0.02,0.17,0.0,0.17,0.00,0.0]%The lower boundary of each parameter
        %             VarMax=[1.8,0.45,0.100,0.40,3.00,0.0,1.50,0.99,15.0]%The upper boundary of each parameter
        %Set the upper and lower boundary of parameters equal to observe the prediction results
        VarMin=[1.678	0.272	0.021	0.087	1.125	0	0.742	0.385	1.716]
        VarMax=[1.678	0.272	0.021	0.087	1.125	0	0.742	0.385	1.716]
        
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3,     3]; % Decimal digits
        fhd= str2func('CSUHSandCallMex');
    case 4 % EBResult
        diary('.\EBResult\Log.DAT');
        disp('Iteration Number and K,n,Rf,C,��,����,Kb,m of EB model as follows:');
        isLineCritical=1;%0-Nonlinear strength criterion(C=0)��1-Linear strength criterion(����=0)
        nVar=8;% Number of parameters
        VarSize=[1 nVar];  % Parameter Matrix Size
        if isLineCritical==1
            %             VarMin=[10.000, 0.001, 0.50, 0.000, 0.00, 0.0, 10.000, 0.001];%The lower boundary of each parameter
            %             VarMax=[2000.0, 0.99, 0.95, 200.0, 60.0, 0.0, 2000.0, 0.99];%The upper boundary of each parameter
            VarMin=[10.000, -0.5, 0.50, 0.000, 0.00, 0.0, 10.000, -0.5];%The lower boundary of each parameter
            VarMax=[2000.0, 0.99, 0.95, 200.0, 60.0, 0.0, 2000.0, 0.99];%The upper boundary of each parameter
        else
            VarMin=[10.000, 0.001, 0.50, 0.0, 0.00, 0.00, 10.000, 0.001];%The lower boundary of each parameter
            VarMax=[2000.0, 0.99, 0.95, 0.0, 60.0, 20.0, 2000.0, 0.99];%The upper boundary of each parameter
            %             VarMin=[10.000,-0.5, 0.50, 0.0, 0.00, 0.00, 10.000, -0.5];%The lower boundary of each parameter
            %             VarMax=[2000.0, 0.99, 0.95, 0.0, 60.0, 20.0, 2000.0, 0.99];%The upper boundary of each parameter
        end
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3];%Decimal digits
        fhd= str2func('EBCallMex');% mex .\EBResult\EBErrorFunc.f90
    case 5 % EBDefOptResult
        diary('.\EBDefOptResult\Log.DAT');
        disp('Iteration Number and K,n,Rf,C,��,����,Kb,m of EB model as follows:');
        isLineCritical=0;%0-������ǿ��׼��1-������ǿ��׼��
        res=duncanEBevDefine(isLineCritical);%
        close all;
        % only use define method to calibration parameters
        para2=[0,1,1];%Ŀ�꺯���Ƿ��Լ�����Ƿ��������ֵ�����ֵ����0����csuhReadInList.txt��1����csuhReadInListZong.txt��
        [errorValue,passpara]=EBDefOptErrorFunc(BestSol.Position,para2)
        outputPictureev;
        return
        
        nVar=8;             % Number of Decision Variables
        VarSize=[1 nVar];   % Decision Variables Matrix Size
        if isLineCritical==1% ������ǿ��-1
            if (res(2)>0 && res(8)>0)
                VarMin=[0.95*res(1)    , 0.7*res(2),  0.95*res(3)  ,  0.9*res(4),	  0.95*res(5),	0.00,	 0.95*res(7)  , 	0.7*res(8)];%������������
                VarMax=[1.05*res(1)   , 1.3*res(2),  1.05*res(3) ,	 1.1*res(4),	  1.05*res(5),	0.00,	1.05*res(7)  ,     1.3*res(8)];%������������
            else
                VarMin=[0.5*res(1)    , 0.001 ,  0.95*res(3)  ,    0.9*res(4),	  0.95*res(5),	0.00,	 0.5*res(7)  , 	0.001];%������������
                VarMax=[1.5*res(1)   , 0.99 ,  1.05*res(3) ,	 1.1*res(4),	  1.05*res(5),	0.00,	1.5*res(7)  ,   0.99];%������������
            end
            lu(1,:)=[10.000, 0.001, 0.50, 0.000, 0.00, 0.0, 10.000, 0.001];%The extent lower boundary of each parameter
            lu(2,:)=[2000.0, 0.99, 0.95, 200.0, 60.0, 0.0, 2000.0, 0.99];%The extent upper boundary of each parameter
            VarMin=(VarMin<lu(1,:)).*lu(1,:)+(VarMin>=lu(1,:)).*VarMin;
            VarMax=(VarMax>lu(2,:)).*lu(2,:)+(VarMax<=lu(2,:)).*VarMax; %pos2���ܴ��ڲ�����Χ���ޣ���������������������
        else% ������ǿ��-0
            if (res(2)>0 && res(8)>0)
                VarMin=[0.95*res(1)    , 0.7*res(2),  0.95*res(3)  ,  0.0,	  0.95*res(5),	0.95*res(6),	 0.95*res(7)  , 	0.7*res(8)];%������������
                VarMax=[1.05*res(1)   , 1.3*res(2),  1.05*res(3) ,	 0.0,	  1.05*res(5),	1.05*res(6),	1.05*res(7)  ,     1.3*res(8)];%������������
            else
                VarMin=[0.5*res(1)    , 0.001 ,  0.95*res(3)  ,   0.0,	  0.95*res(5),	0.95*res(6),	 0.95*res(7)  , 	0.001];%������������
                VarMax=[1.5*res(1)   , 0.999 ,  1.05*res(3) ,	 0.0,	  1.05*res(5),	1.05*res(6),	1.05*res(7)  ,      0.99];%������������
            end
            lu(1,:)=[10.000, 0.001, 0.50, 0.0, 0.00, 0.00, 10.000, 0.001];%The extent lower boundary of each parameter
            lu(2,:)=[2000.0, 0.99, 0.95, 0.0, 60.0, 20.0, 2000.0, 0.99];%The extent upper boundary of each parameter
            VarMin=(VarMin<lu(1,:)).*lu(1,:)+(VarMin>=lu(1,:)).*VarMin;
            VarMax=(VarMax>lu(2,:)).*lu(2,:)+(VarMax<=lu(2,:)).*VarMax; %pos2���ܴ��ڲ�����Χ���ޣ���������������������
        end
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3];%С������Ҳ��м�λС��
        fhd= str2func('EBDefOptCallMex'); %
    case 6 %GCLResult
        diary('.\GCLResult\Log.DAT');
        disp('Iteration Number and elambda,lambda,xi,pci,K0,G0,Mg,alpha,lmg,Mf,H0,sm of GCL model (for sands) as follows:');
        nVar=12; % Number of Decision Variables
        VarSize=[1 nVar];% Decision Variables Matrix Size
        VarMin=[0.2,0.01,0.01,1.0000,10.000,10.000,0.8,0.1, -2.0, 0.8,1.00000,  -2.0];%������������ sand
        VarMax=[2.0,0.40,0.40,5000.0,1000.0,1000.0,1.9,2.0,  2.0 , 1.9,10000.0,  2.0];%������������
        %         VarMin=[0.628 0.029 0.043  1262.7 10  10   1.2 0.5 -0.299   1.0 5000 -2.05];%������������ ����ʦ�����޸�
        %         VarMax=[0.628 0.029  0.043 1262.7 500 500 1.8 0.5 -0.299 1.8 7000  0.0];%������������
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3, 3,  3,  3,  3];%С������Ҳ��м�λС��
        fhd= str2func('GCLCallMex');
    case 7 %SSHResult
        diary('.\SSHResult\Log.DAT');
        disp('Iteration Number and PROPM,ENU,PKAPPA,PLAMDA,PNVOID,U_R,PHI_D,MU of SSH model(for clays) as follows:');
        nVar=8;
        VarSize=[1 nVar];
        VarMin=[0.6,   0.05,  0.002,    0.02,    0.17,    0.0,     0.0,   0.0];%������������ sand
        VarMax=[1.8,   0.45,  0.100,    0.40,    3.00,  100.0,   40.0,  3.0];%������������
        
        %         VarMin=[1.139	0.408	0.005	0.061	0.751	50	0	0];%������������ clay
        %         VarMax=[1.139	0.408	0.005	0.061	0.751	50	0	0];%������������
        
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3];%С������Ҳ��м�λС��
        fhd= str2func('SSHCallMex');
    case 100 % usedefine( default CSUH)
        diary('.\UserDefineResult\Log.DAT');
        disp('Iteration Number��PROPM,ENU,PKAPPA,PLAMDA,PNVOID,C,Z,CHI,SM');
        nVar=9;
        VarSize=[1 nVar];
        VarMin=[0.8,   0.05,  0.002,    0.02,    0.17,    0.0,   0.17,   0.000,  0.0];%
        VarMax=[1.8,   0.45,  0.100,    0.40,    3.00,     0.0,   1.50,   0.99,  10.0];%
        NumRDP=[ 3,      3,     3,       3,      3,      3,       3,     3,     3];%С������Ҳ��м�λС��
        fhd= str2func('UserDefineCallMex');
    otherwise
        disp('there is no choose constitive model!')
        return;
end
%% Set up Algorithm
pop_size=30;%2^(4+floor(log2(sqrt(D)))); % Do not change this value
group_size=3; % Do not change this value

if autoOpt==0 % autoOpt=0 means no automatic optimization but only compute one generation to output picture��
    %% If you know the model parameters, use the codes below to validate the drawing only
    fes_max=30*nVar%
    iter_max=1 % Iterate only once
    group_num=3; % group_num=20+round(D/10);
    
else % autoOpt=1 means automatic optimization using MAPSO  algorithms and output picture;
    %%% If you use the MAPSO optimization algorithm to optimize the parameters, use the following codes
    fes_max=15000*nVar %  can change this value
    iter_max=ceil(fes_max/pop_size) % can change this value
    group_num=25; % group_num=20+round(nVar/10); % can change this value
end
%% Unused Settings
jingdu=0; % precision
func_num=1;%�ڼ�������,δʹ��
para2=[1,0,0,ErrorType];%Ŀ�꺯���Ƿ��Լ�����Ƿ��������ֵ,��0����csuhReadInList.txt��1����csuhReadInListZong.txt��
%% MAPSO algorithm was used for optimization
[gbest,gbestval,FES,suc,suc_fes]= MAPSO_func(jingdu,func_num,fhd,nVar,...
    group_size,group_num,iter_max,fes_max,VarMin,VarMax,NumRDP,para2);
%% output theory(predicted) data and output pictures
figure(1);
if ~isempty(iterGbestval)
    plot(iterGbestval(:,1),iterGbestval(:,2),'.');hold on;
    % semilogy(iterGbestval(:,1),iterGbestval(:,2),'.');
    
    % semilogy(BestCost,'LineWidth',2);%yΪ������������׿������ں�û���Ż��ĸ���
    %     plot(BestCost(1:it),'Marker','o','LineWidth',1);
    it=iterGbestval(end,1);
    text(round(it/2),BestSol.Cost+3,['self-cost:' num2str(BestSol.Cost) ]);
    xlabel('Iteration');
    ylabel('Error/%');
    grid on;
end

% calculate error of all data and output the pictures
switch constitiveModel
    case 1%MCC
        para2=[0,1,1];%Whether the objective function is constrained;Whether to output theoretical value and error value; 0 means read csuhReadInList.txt, 1 read csuhReadInListZong.txt
        [errorValue,passpara]=MCCErrorFunc(BestSol.Position,para2);%output the theory(pridicted) data
        %         disp('the passpara:');
        %         passpara%output the passpara data
        text(round(it/2)*1.2,BestSol.Cost+6,['total cost:' num2str(errorValue) '%']);
        saveas(gcf,'.\MCCResult\0-Cost' ,'png'); %save the current figure
        outputPictureev;% output all the picture
    case 2%CSUHClay
        %%% sensitivity analysis
        %         para2=[0,0,0,ErrorType];
        %         LowerUperPercent=0.2;
        %         PointerNum=100;
        %         CSS=SACSS(fhd,BestSol.Position,para2,LowerUperPercent,PointerNum,VarMin,VarMax,NumRDP);% Sensitivity analysis  https://doi.org/10.1002/nag.2714
        
        %         %%% ���ݸ������������������� SelfError �� TotalError
        basicPara=[
            ];%ÿ��һ�����
        %         SelfError: ����csuhReadInList.txt
        %         para2=[1,0,0,ErrorType];%��Լ�����������txt������list���������
        %         SelfError=CSUHClayCallMex(basicPara',para2);SelfError=SelfError';
        %         % TotalError: ����csuhReadInListZong.txt
        %         para2=[0,0,1,ErrorType];%����Լ�����������txt������listzong���������
        %         TotalError=CSUHClayCallMex(basicPara',para2);TotalError=TotalError';
        
        para2=[0,1,1,ErrorType];%Ŀ�꺯���Ƿ��Լ�����Ƿ��������ֵ�����ֵ����0����csuhReadInList.txt��1����csuhReadInListZong.txt��
        BestSol.Position(7)=BestSol.Position(5);% Z=N
        [errorValue,passpara]=CSUHClayErrorFunc(BestSol.Position,para2);%�������ֵ
        %         disp('the passpara:');
        %         passpara%�����������
        
        text(round(it/2)*1.2,BestSol.Cost+6,['total cost:' num2str(errorValue) ]);
        saveas(gcf,'.\CSUHClayResult\0-Cost' ,'png'); %���浱ǰ���ڵ�ͼ��
        outputPictureev;% ��ͼ
    case 3 %CSUHSand
        %%% sensitivity analysis
        %          para2=[0,0,0,ErrorType];
        %          LowerUperPercent=0.2;
        %          PointerNum=20;
        %         CSS=SACSS(fhd,BestSol.Position,para2,LowerUperPercent,PointerNum,VarMin,VarMax,NumRDP);% Sensitivity analysis  https://doi.org/10.1002/nag.2714
        %%% sensitivity analysis
        
        % % ���ݸ������������������� SelfError �� TotalError.
        % basicPara=[
        %
        % ];%ÿ��һ�����
        % %SelfError: ����csuhReadInList.txt
        % para2=[1,0,0,ErrorType];%��Լ�����������txt������list���������
        % SelfError=CSUHSandCallMex(basicPara',para2);SelfError=SelfError';
        % % TotalError: ����csuhReadInListZong.txt
        % para2=[0,0,1,ErrorType];%����Լ�����������txt������listzong���������
        % TotalError=CSUHSandCallMex(basicPara',para2);TotalError=TotalError';
        
        
        %%%��������txt
        para2=[0,1,1,ErrorType];
        [errorValue,passpara]=CSUHSandErrorFunc(BestSol.Position,para2);
        
        %         disp('the passpara:');
        %         passpara
        text(round(it/2)*1.2,BestSol.Cost+6,['total cost:' num2str(errorValue) ]);
        saveas(gcf,'.\CSUHSandResult\0-Cost' ,'png');
        outputPictureev;
    case 4 %EB
        para2=[0,1,1];
        [errorValue,passpara]=EBErrorFunc(BestSol.Position,para2);%
        %         disp('the passpara:');
        %         passpara
        text(round(it/2)*1.5,BestSol.Cost+6,['total cost:' num2str(errorValue) '%']);
        saveas(gcf,'.\EBResult\0-Cost' ,'png');
        outputPictureev;
    case 5 %EBDefOpt
        para2=[0,1,1];
        [errorValue,passpara]=EBDefOptErrorFunc(BestSol.Position,para2)
        text(round(it/2)*1.5,BestSol.Cost+6,['total cost:' num2str(errorValue) '%']);
        saveas(gcf,'.\EBDefOptResult\0-Cost' ,'png');
        outputPictureev;
    case 6 %GCL model
        para2=[0,1,1];
        [errorValue,passpara]=GCLErrorFunc(BestSol.Position,para2);
        %         disp('the passpara:');
        %         passpara
        text(round(it/2)*1.2,BestSol.Cost+6,['total cost:' num2str(errorValue) '%']);
        saveas(gcf,'.\GCLResult\0-Cost' ,'png');
        outputPictureev;
    case 7 %SSH
        para2=[0,1,1];
        [errorValue,passpara]=SSHErrorFunc(BestSol.Position,para2);
        %         disp('the passpara:');
        %         passpara
        text(round(it/2)*1.2,BestSol.Cost+6,['total cost:' num2str(errorValue) '%']);
        saveas(gcf,'.\SSHResult\0-Cost' ,'png');
        outputPictureev;
        
    case 100 %csuh
        para2=[0,1,1];
        [errorValue,passpara]=UserDefineErrorFunc(BestSol.Position,para2);%
        %         disp('the passpara:');
        %         passpara%
        text(round(it/2)*1.2,BestSol.Cost+6,['total cost:' num2str(errorValue) '%']);
        saveas(gcf,'.\UserDefineResult\0-Cost' ,'png');
        outputPictureev;
    otherwise
        disp('please select a existing constitutive model !')
end
disp(['Error Value of partital data(ReadInList.txt):' num2str(BestSol.Cost) '(%):']);
bestParaError=BestSol.Cost;% �ٷ���
disp('the best individuals:')
bestPara=(BestSol.Position)';%������������׿�����abaqus��
fprintf('%12.4f ',bestPara);
disp(' ');
disp('All data error(ReadInListZong.txt)%:');
disp(errorValue);
disp(['end~~, using ' num2str(round(toc/60,2)) ' min'])
diary off;
%% delete the search path
rmpath(pathstr);
rmpath([pathstr '\MCCResult']);
rmpath([pathstr '\CSUHClayResult']);
rmpath([pathstr '\CSUHSandResult']);
rmpath([pathstr '\EBResult']);
rmpath([pathstr '\EBDefOptResult']);
rmpath([pathstr '\GCLResult']);
rmpath([pathstr '\SSHResult']);
rmpath([pathstr '\userDefineResult']);
res =savepath;
fclose('all');% close all opend text
%% The whistle of the train is a reminder that the calculation is finished
load train
sound(y,Fs)

