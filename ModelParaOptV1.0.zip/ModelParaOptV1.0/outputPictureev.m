% close all;%�ر����л�ͼ����
%% ��ͼ����
figNum=1;
e1Times=100;%e1��ev���ðٷ��ƻ���С��λ���ٷ�����100��С��λ��1
lgdStyle=1;% *** 1����֮ǰ��legend��ʽ��2����������ʱ�ֶ�����ĸ�ʽ��
% isSort=1;% �Ƿ�����������ã�������
formattype='png';% ���ͼƬ�ĸ�ʽ��png  fig  tif  %saveas(gcf,[picPath

printfmttp='-dtiff';
% printfmttp='-depsc';%'-depsc'��ɫ��eps��ʽ���� '-deps'�ڰ�eps��ʽ����
fdpi='-r800';%����������800dpi�ķֱ���
legendonoff='on';% �Ƿ���ʾlegend �����Ҳû�ã��������lgd1Visible lgd2Visible�ֱ����
Boxonoff='off';% legend�Ƿ���ʾ�߿�
XGridOnOff='off';% Axes�Ƿ���ʾX���grid
YGridOnOff='off';
lgdLeftTitle='experiment';% ���legend��title
% lgdRightTitle='theory';
lgdexperiment=''; % ���legendÿ����Ŀ������
lgd1Visible='on';% ���Ƶ�һ��Ҳ������ߵ�legend�Ƿ���ʾ
lgd2Visible='on';
lgd1TitleVisibleOnOff='off';
lgd2TitleVisibleOnOff='off';

% formatSpec='p_0=%gkPa e_0=%0.3g';
% formatSpec='p=%gkPa e=%0.3f';
% lgdRightTitle='theory(p_0,e_0)';% %�ұߵ�legend��title
lgdRightTitle='theory';% %�ұߵ�legend��title
formatSpec='%gkPa,%0.3f'; % legend ��Ŀ��ʽ���Ʒ�
scSortDirection='ascend';%direction  sort Ĭ������ascend ��Ҳ����ѡ����descend
iniVoidRatioDirection='descend';% ��ʼ��϶����������
FontSize=16;%�����С
FontName='Times new Roman';%�����ͺ�
axesTitleVisible='off';% ͼƬ��title�Ƿ���ʾ
% Location with respect to the axes
% 'north'	Inside top of axes
% 'south'	Inside bottom of axes
% 'best'	Inside axes where least conflict with data in plot
% 'bestoutside'	To the right of the axes
% 'none'	Determined by Position property. Use the Position property to specify a custom location.
Location= 'best';

%% global pathstr;%����ȫ�ֱ���
% global constitiveModel;%����ȫ�ֱ���������ѡ�񱾹�ģ��
% global BestSol;
% ������ģ����Ҫ�Ķ��ĵط�
switch constitiveModel
    case 1
        filename='.\MCCResult\evReadInListZong.txt';
        picPath='.\MCCResult\';
        midpeFileName='.\MCCResult\MidPande.DAT';
    case 2
        filename='.\CSUHClayResult\evReadInListZong.txt';
        picPath='.\CSUHClayResult\';
        midpeFileName='.\CSUHClayResult\MidPande.DAT';
    case 3
        filename='.\CSUHSandResult\evReadInListZong.txt';
        picPath='.\CSUHSandResult\';
        midpeFileName='.\CSUHSandResult\MidPande.DAT';
    case 4
        filename='.\EBResult\evReadInListZong.txt';
        picPath='.\EBResult\';
        midpeFileName='.\EBResult\MidPande.DAT';
    case 5
        filename='.\EBDefOptResult\evReadInListZong.txt';
        picPath='.\EBDefOptResult\';
        midpeFileName='.\EBDefOptResult\MidPande.DAT';
    case 6
        filename='.\GCLResult\evReadInListZong.txt';
        picPath='.\GCLResult\';
        midpeFileName='.\GCLResult\MidPande.DAT';
    case 7
        filename='.\SSHResult\evReadInListZong.txt';
        picPath='.\SSHResult\';
        midpeFileName='.\SSHResult\MidPande.DAT';
        
    case 100
        filename='.\userDefineResult\evReadInListZong.txt';
        picPath='.\userDefineResult\';
        midpeFileName='.\userDefineResult\MidPande.DAT';
        
    otherwise
        disp('there is no choose constitive model!')
        return;
end


fileID = fopen(filename);

switch constitiveModel
    case 1
        C=textscan(fileID,'%s %f %f %f %f','delimiter', ',');%MCCģ�Ͷ������һ��ǰ�ڹ̽�ѹ��pc
    otherwise
        C=textscan(fileID,'%s %f %f %f','delimiter', ',');
end

LengthC=length(C{1,1});
for k=1:LengthC
    
    strTem='';
    strTem=string((C{1,1}(k,1)));
    TextList(k)=strTem;%�����ĵ��б�
    myType(k)=(C{1,2}(k,1));
    
    
    charTem=char(strTem);
    filenameLength=length(charTem);
    %     filenameLength2=size(strTem);
    lianjiefu='-';
    charTem=charTem(1:filenameLength-4);
    filename='';
    filename=[charTem(1:filenameLength-4),lianjiefu,num2str(myType(k)),'.DAT'];
    TextListOut(k)=string(filename);%����ĵ��б�
end

[midp,mide]=textread(midpeFileName,'%f %f')
[myType,indexMytype2]=sort(myType);
TextList=TextList(indexMytype2);
TextListOut=TextListOut(indexMytype2);

midp=midp(indexMytype2);
mide=mide(indexMytype2);

uniTestType=unique(myType);%���м�������
for ii=1:numel(uniTestType)
    eachTestNum(ii)=numel(find(myType==uniTestType(ii)));%ÿ������ĸ���
end

textNums=length(TextListOut);%�м����ı��ĵ�
sc=zeros(1,textNums);%�̽��Χѹ
iniVoidRatio=zeros(1,textNums);%�̽���ʼ��϶��
% ����������ĵ����Ʋ������������ֵ�ĵ�����
for i=1:textNums
    filename='';
    filename=char(TextList(i));
    data=load(filename,'-ascii');
    [m,n]=size(data);
    DataLines(i)=m;%ÿ�������ĵ�����
    for j=1:m%ÿ�������ĵ�����
        for k=1:n%n��
            ArrayLabData(i,j,k)=data(j,k);
            if(k==4)
                ArrayLabData(i,j,k)=mide(i)- ArrayLabData(i,j,k)*(1+mide(i));%���ݳ�ʼ��϶�ȼ�����п�϶��
            end
        end
        ArrayLabDataev(i,j)=(ArrayLabData(i,1,4)-ArrayLabData(i,j,4))/(1+ArrayLabData(i,1,4));%��i��ʵ�������ĵ�����k�п�϶��ת��Ϊev
    end
    sc(i)=ArrayLabData(i,1,3);
    iniVoidRatio(i)=mide(i);
end


%����csl������
if  (constitiveModel==2 || constitiveModel==3) % csuh
    CSLPara=BestSol.Position;% 1-M 2-v 3-kappa 4-lambda 5-N 6-C 7-Z 8-chi 9-m
    % CSLpX=0.5*min(sc):1:2*max(sc);
    % CSLpX=0.5*min(sc):1:2*max(sc);
    %CSL
    CSLpX=0*min(sc):1:50*max(sc);
    CSUHPs=exp((CSLPara(5)-CSLPara(7))/CSLPara(4))-1;% ps=exp((N-Z)/lambda)-1
    CSLeY=CSLPara(7)-CSLPara(4)*log((CSLpX+CSUHPs)./(1+CSUHPs))-...
        (CSLPara(4)-CSLPara(3))*log(((2.0/(1.0-CSLPara(8)))*CSLpX+CSUHPs)./(CSLpX+CSUHPs));
    CSLgtzIndex=CSLeY>0;
    CSLpX=CSLpX(CSLgtzIndex);
    CSLeY=CSLeY(CSLgtzIndex);
    
    %NCL
    NCLpX=0*min(sc):1:50*max(sc);
    NCLeY=CSLPara(7)-CSLPara(4)*log((NCLpX+CSUHPs)./(1+CSUHPs));
    NCLgtzIndex=NCLeY>0;
    NCLpX=NCLpX(NCLgtzIndex);
    NCLeY=NCLeY(NCLgtzIndex);
end


% ������������
for i=1:textNums
    filename='';
    filename=char(TextListOut(i));
    data=load(filename,'-ascii');
    [m,n]=size(data);
    DataLinesT(i)=m;%ÿ�������ĵ�����
    for j=1:m
        for k=1:n
            ArrayTheoryData(i,j,k)=data(j,k);
            %������Ϊ��϶��
            if(k==4)
                ArrayTheoryData(i,j,k)=mide(i)- ArrayTheoryData(i,j,k)*(1+mide(i));
            end
        end
        ArrayTheoryDataev(i,j)=(ArrayTheoryData(i,1,4)-ArrayTheoryData(i,j,4))/(1+ArrayTheoryData(i,1,4));%��i��ʵ�������ĵ�����k�е�ev
    end
end
% ��ͼ ��Ϊ5��Ӧ��·��
% ��ɫ
color=[1 0 0;0 1 0;0 0 1;0.5 0.1 0;0 0.3 0.4;0.6 0.7 0.2;0.5 0.8 0.9;0 0.2 0.1;0.1 0.5 0;0.1 0 0.5;0.5 0 0.1];%12����ɫ һ����ɫ��һ��
% ���
marker=['o','+','*','.','x','s','d','^','v','>','<','p','h'];%13�ֱ�� һ����Ҳ��һ��; �ַ����飬ÿ���ַ�ռ1��λ��
% useM=1;
% ����
linestyle=[string('-'),string('--'),string(':'),string('-.'),string('none')];
useL=5;
% ͼ��
%% ��ʼ��ͼ
istart=[0 cumsum(eachTestNum)]+1;%ÿ�������ͼ��ArrayLabData��ʼ��
eachTestNum=cumsum(eachTestNum);%ÿ�������ͼ��ArrayLabData������
for ii=1:numel(eachTestNum)%ѭ����ͬ���������ͣ��ò�ͬ������ͼ
    jj=uniTestType(ii);%��������
    switch jj %1��������ˮ��2������p��3����Χѹ���䣬4��������,5.����ѹ��
        %% CU
        case 1% 1��������ˮ ���ƣ�1-CU-:e1-q e1-u p-q e1-eta e1-e lnp-e+csl
            % ea-q
            figNum=figNum+1;
            figure(figNum);%1-CU-ea-q ����ֵ   get(fig,'Children')
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),2)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-e1-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),2)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\itq} / kPa','FontWeight','bold');
            title('{\itCU:}{\it\epsilon}_a / % - {\itq}');
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            % ��ǰ�õ��� ����Χѹ�Ϳ�϶��
            thisTypeSc=sc(istart(ii):eachTestNum(ii));
            thisTypeVoidRatio=iniVoidRatio(istart(ii):eachTestNum(ii));
            %����һ��table��ʵ���ȶԱ�����Χѹ����������Χѹ��ͬ���ٶԿ�϶�Ƚ�������
            tableSCVR = table;%����һ������
            tableSCVR.sc=thisTypeSc';% ������
            tableSCVR.vr=thisTypeVoidRatio';% ������
            %             [tableSCVR2,scvrIndex]=sortrows(tableSCVR,[1,2],{scSortDirection,iniVoidRatioDirection});%Ĭ��'ascend'���� {'ascend','descend'} ,iniVoidRatioDirection���������ǽ���
            [~,scvrIndex]=sortrows(tableSCVR,{'sc','vr'},{scSortDirection ,iniVoidRatioDirection});%Ĭ��'ascend'���� {'ascend','descend'} ,iniVoidRatioDirection���������ǽ���
            % Ȼ��� ��Ӧ�Ŀ�϶�ȡ�����ֵ������ֵ�����ľ�������ƶ�
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            thisTypeSc=thisTypeSc(scvrIndex);
            thisTypeVoidRatio=thisTypeVoidRatio(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='1-CU-ea-q';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                scAlf1=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                scAlf2=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='1-CU-ea-q';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            % ea-u
            figNum=figNum+1;
            figure(figNum);%1-CU-ea-u ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),5)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-e1-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),5)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\itu} / kPa','FontWeight','bold');
            title('{\itCU:}{\it\epsilon}_a / % - {\itu}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='1-CU-ea-u';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='1-CU-ea-u';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            % p-q
            figNum=figNum+1;
            figure(figNum);%1-CU-p-q ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),3)),(ArrayLabData(i,1:DataLines(i),2)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-p-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),3)),(ArrayTheoryData(i,1:DataLinesT(i),2)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\itp}{''} / kPa','FontWeight','bold');
            ylabel('{\itq} / kPa','FontWeight','bold');
            title('{\itCU:}{\itp}{''} - {\itq}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='1-CU-p-q';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='1-CU-p-q';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            % ea-eta
            figNum=figNum+1;
            figure(figNum);%1-CU-ea-eta ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),ArrayLabData(i,1:DataLines(i),2)./ArrayLabData(i,1:DataLines(i),3),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-ea-eta ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),2))./ArrayTheoryData(i,1:DataLines(i),3),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\it\eta}','FontWeight','bold');
            title('{\itCU:}{\it\epsilon}_a / % - {\it\eta}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='1-CU-ea-eta';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='1-CU-ea-eta';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %lnp-e+csl
            figNum=figNum+1;
            figure(figNum);%1-cu-lnp-e ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=semilogx((ArrayLabData(i,1:DataLines(i),3)),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%5-ISO-lnp-e ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=semilogx((ArrayTheoryData(i,1:DataLinesT(i),3)),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            if (constitiveModel==2 ) ||   (constitiveModel==3 )
                semilogx(CSLpX,CSLeY,'LineStyle','-','Color','red','LineWidth',1.2);
                line([CSUHPs,CSUHPs],[0,CSLPara(7)],'LineStyle','--','Color','k','LineWidth',0.2);
                text(CSUHPs,CSLPara(7)/2,[ '{\it p_s=}' num2str(CSUHPs) '{\itkPa}']);
                hold on;
                semilogx(NCLpX,NCLeY,'LineStyle','-','Color','blue','LineWidth',1.2);
                hold on;
            end
            
            xlabel('{\itlnp}{''} / kPa','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itCU:}{\itlnp}{''} - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='1-CU-lnp-e-CSL';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='1-CU-lnp-e-CSL';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %% 2������p
        case 2% 2������p ���ƣ�2-CP-:e1-q e1-ev e1-e  lnp-e+csl
            % ea-q
            figNum=figNum+1;
            figure(figNum);%2-CP-ea-q ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),2)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%2-CP-ea-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),2)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\itq} / kPa','FontWeight','bold');
            title('{\itCP:}{\it\epsilon}_a / % - {\itq}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            
            % ��ǰ�õ��Ĳ��� Χѹ�Ϳ�϶��
            thisTypeSc=sc(istart(ii):eachTestNum(ii));
            thisTypeVoidRatio=iniVoidRatio(istart(ii):eachTestNum(ii));
            %����һ��table��ʵ���ȶԱ�����Χѹ����������Χѹ��ͬ���ٶԿ�϶�Ƚ�������
            tableSCVR = table;%����һ������
            tableSCVR.sc=thisTypeSc';% ������
            tableSCVR.vr=thisTypeVoidRatio';% ������
            [~,scvrIndex]=sortrows(tableSCVR,[1,2],{scSortDirection,iniVoidRatioDirection});%{'ascend','descend'} ,iniVoidRatioDirection���������ǽ���
            % Ȼ��� ��Ӧ�Ŀ�϶�ȡ�����ֵ������ֵ�����ľ�������ƶ�
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            thisTypeSc=thisTypeSc(scvrIndex);
            thisTypeVoidRatio=thisTypeVoidRatio(scvrIndex);
            
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='2-CP-ea-q';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                scAlf1=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                scAlf2=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='2-CP-ea-q';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            % ea-ev
            figNum=figNum+1;
            figure(figNum);%2-CP-ea-ev ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabDataev(i,1:DataLines(i))*e1Times),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%2-CP-ea-ev ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryDataev(i,1:DataLinesT(i))*e1Times),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\it\epsilon}_v / %','FontWeight','bold');
            title('{\itCP:}{\it\epsilon}_a / % - {\it\epsilon}_v / %');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='2-CP-ea-ev';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='2-CP-ea-ev';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %e1-e
            figNum=figNum+1;
            figure(figNum);%2-CP-ea-e ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-e1-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itCP:}{\it\epsilon}_a / % - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='2-CP-ea-e';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='2-CP-ea-e';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %lnp-e+csl
            figNum=figNum+1;
            figure(figNum);%2-CP-lnp-e+CSL ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=semilogx((ArrayLabData(i,1:DataLines(i),3)),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%5-ISO-lnp-e ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=semilogx((ArrayTheoryData(i,1:DataLinesT(i),3)),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            
            if (constitiveModel==2 ) ||   (constitiveModel==3 )
                semilogx(CSLpX,CSLeY,'LineStyle','-','Color','red','LineWidth',1.2);
                line([CSUHPs,CSUHPs],[0,CSLPara(7)],'LineStyle','--','Color','k','LineWidth',0.2);
                text(CSUHPs,CSLPara(7)/2,[ '{\it p_s=}' num2str(CSUHPs) '{\it kPa}']);
                hold on;
                semilogx(NCLpX,NCLeY,'LineStyle','-','Color','blue','LineWidth',1.2);
                hold on;
            end
            
            xlabel('{\itlnp}{''} / kPa','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itCP:}{\itlnp}{''} - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='2-CP-lnp-e+CSL';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='2-CP-lnp-e-CSL';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %% 3����Χѹ����
        case 3% 3����Χѹ���� ���ƣ�3-CD-:e1-q e1-ev e-q e1-eta
            % ea-q
            figNum=figNum+1;
            figure(figNum);%3-CD-ea-q ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),2)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%3-CD-ea-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),2)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\itq} / kPa','FontWeight','bold');
            title('{\itCD:}{\it\epsilon}_a / % - {\itq}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            
            % ��ǰ�õ��Ĳ��� Χѹ�Ϳ�϶��
            thisTypeSc=sc(istart(ii):eachTestNum(ii));
            thisTypeVoidRatio=iniVoidRatio(istart(ii):eachTestNum(ii));
            %����һ��table��ʵ���ȶԱ�����Χѹ����������Χѹ��ͬ���ٶԿ�϶�Ƚ�������
            tableSCVR = table;%����һ������
            tableSCVR.sc=thisTypeSc';% ������
            tableSCVR.vr=thisTypeVoidRatio';% ������
            [~,scvrIndex]=sortrows(tableSCVR,[1,2],{scSortDirection,iniVoidRatioDirection});%{'ascend','descend'} ,iniVoidRatioDirection���������ǽ���
            % Ȼ��� ��Ӧ�Ŀ�϶�ȡ�����ֵ������ֵ�����ľ�������ƶ�
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            thisTypeSc=thisTypeSc(scvrIndex);
            thisTypeVoidRatio=thisTypeVoidRatio(scvrIndex);
            
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='3-CD-ea-q';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                scAlf1=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                scAlf2=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='3-CD-ea-q';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            
            % ea-ev
            figNum=figNum+1;
            figure(figNum);%3-CD-ea-ev ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabDataev(i,1:DataLines(i))*e1Times),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%3-CD-ea-ev ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryDataev(i,1:DataLinesT(i))*e1Times),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\it\epsilon}_v / %','FontWeight','bold');
            title('{\itCD:}{\it\epsilon}_a / % - {\it\epsilon}_v / %');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='3-CD-ea-ev';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='3-CD-ea-ev';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            
            % e-q
            figNum=figNum+1;
            figure(figNum);%3-CD-e-q ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),4)),(ArrayLabData(i,1:DataLines(i),2)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%3-CD-e-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),4)),(ArrayTheoryData(i,1:DataLinesT(i),2)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\ite}','FontWeight','bold');
            ylabel('{\itq} / kPa','FontWeight','bold');
            title('{\itCD:}{\ite} - {\itq}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='3-CD-e-q';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='3-CD-e-q';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            
            % ea-eta
            figNum=figNum+1;
            figure(figNum);%3-CD-ea-eta ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),ArrayLabData(i,1:DataLines(i),2)./ArrayLabData(i,1:DataLines(i),3),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%3-CD-ea-eta ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),2))./ArrayTheoryData(i,1:DataLines(i),3),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);%  '-','color',color(ci,:),'LineWidth',1
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\it\eta}','FontWeight','bold');
            title('{\itCD:}{\it\epsilon}_a / % - {\it\eta}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='3-CD-ea-eta';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='3-CD-ea-eta';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            %e1-e
            figNum=figNum+1;
            figure(figNum);%3-CD-ea-e ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-e1-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itCD:}{\it\epsilon}_a / % - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='3-CD-ea-e';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='3-CD-ea-e';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %lnp-e+csl
            figNum=figNum+1;
            figure(figNum);%3-CD-lnp-e+CSL ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=semilogx((ArrayLabData(i,1:DataLines(i),3)),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%5-ISO-lnp-e ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=semilogx((ArrayTheoryData(i,1:DataLinesT(i),3)),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            
            if (constitiveModel==2 ) ||   (constitiveModel==3 )
                semilogx(CSLpX,CSLeY,'LineStyle','-','Color','red','LineWidth',1.2);
                line([CSUHPs,CSUHPs],[0,CSLPara(7)],'LineStyle','--','Color','k','LineWidth',0.2);
                text(CSUHPs,CSLPara(7)/2,[ '{\it p_s=}' num2str(CSUHPs) '{\itkPa}']);
                hold on;
                semilogx(NCLpX,NCLeY,'LineStyle','-','Color','blue','LineWidth',1.2);
                hold on;
            end
            
            xlabel('{\itlnp}{''} / kPa','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itCD:}{\itlnp}{''} - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='3-CD-lnp-e-CSL';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='3-CD-lnp-e-CSL';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            %% 4��������
        case 4% 4�������� ���ƣ�4-K0-:ea-sigma1��sigma1=p+2/3q���� ea-sigma3��sigma3=p-1/3q�� ��lnp-e
            % ea-sigma1��sigma1=p+2/3q��
            figNum=figNum+1;
            figure(figNum);%4-K0-ea-q ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),...
                    (ArrayLabData(i,1:DataLines(i),3)+2/3*ArrayLabData(i,1:DataLines(i),2)),...
                    'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%4-K0-ea-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),...
                    (ArrayTheoryData(i,1:DataLinesT(i),3)+2/3*ArrayTheoryData(i,1:DataLinesT(i),2)),...
                    'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\it\sigma}_1 / kPa','FontWeight','bold');
            title('{\itK0:}{\it\epsilon}_a / % - {\it\sigma}_1');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            % ��ǰ�õ��Ĳ��� Χѹ�Ϳ�϶��
            thisTypeSc=sc(istart(ii):eachTestNum(ii));
            thisTypeVoidRatio=iniVoidRatio(istart(ii):eachTestNum(ii));
            %����һ��table��ʵ���ȶԱ�����Χѹ����������Χѹ��ͬ���ٶԿ�϶�Ƚ�������
            tableSCVR = table;%����һ������
            tableSCVR.sc=thisTypeSc';% ������
            tableSCVR.vr=thisTypeVoidRatio';% ������
            [~,scvrIndex]=sortrows(tableSCVR,[1,2],{scSortDirection,iniVoidRatioDirection});%{'ascend','descend'} ,iniVoidRatioDirection���������ǽ���
            % Ȼ��� ��Ӧ�Ŀ�϶�ȡ�����ֵ������ֵ�����ľ�������ƶ�
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            thisTypeSc=thisTypeSc(scvrIndex);
            thisTypeVoidRatio=thisTypeVoidRatio(scvrIndex);
            
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='4-K0-ea-siga';%siga=sig1 Ϊ�������ӵĳ��ȵ�Чѹǿ
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                scAlf1=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                scAlf2=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='4-K0-ea-siga';%siga=sig1 Ϊ�������ӵĳ��ȵ�Чѹǿ
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            % ea-sigma3��sigma3=p-1/3q��
            figNum=figNum+1;
            figure(figNum);%4-K0-ea-sigma3 ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),...
                    (ArrayLabData(i,1:DataLines(i),3)-1/3*ArrayLabData(i,1:DataLines(i),2)),...
                    'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%4-K0-ea-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),...
                    (ArrayTheoryData(i,1:DataLinesT(i),3)-1/3*ArrayTheoryData(i,1:DataLinesT(i),2)),...
                    'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\it\sigma}_3 / kPa','FontWeight','bold');
            title('{\itK0:}{\it\epsilon}_a / % - {\it\sigma}_3');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='4-K0-ea-sig3';%siga=sig1 Ϊ�������ӵĳ��ȵ�Чѹǿ
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='4-K0-ea-sig3';%siga=sig1 Ϊ�������ӵĳ��ȵ�Чѹǿ
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            %e1-e
            figNum=figNum+1;
            figure(figNum);%4-K0-ea-e ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=plot((ArrayLabData(i,1:DataLines(i),1)*e1Times),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%1-CU-e1-q ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=plot((ArrayTheoryData(i,1:DataLinesT(i),1)*e1Times),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\it\epsilon}_a / %','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itK0:}{\it\epsilon}_a / % - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='4-K0-ea-e';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf1=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf2=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='4-K0-ea-e';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            % lnp-e
            figNum=figNum+1;
            figure(figNum);%4-K0-lnp-e ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=semilogx((ArrayLabData(i,1:DataLines(i),3)),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%4-K0-lnp-e ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=semilogx((ArrayTheoryData(i,1:DataLinesT(i),3)),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            
            if (constitiveModel==2 ) ||   (constitiveModel==3 )
                semilogx(CSLpX,CSLeY,'LineStyle','-','Color','red','LineWidth',1.2);
                line([CSUHPs,CSUHPs],[0,CSLPara(7)],'LineStyle','--','Color','k','LineWidth',0.2);
                text(CSUHPs,CSLPara(7)/2,[ '{\it p_s=}' num2str(CSUHPs)+'{\itkPa}']);
                hold on;
                semilogx(NCLpX,NCLeY,'LineStyle','-','Color','blue','LineWidth',1.2);
                hold on;
            end
            
            xlabel('{\itlnp}{''} / kPa','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itK0:}{\itlnp}{''} - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='4-K0-lnp-e';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(lgdexperiment));% ����ʾ������
                %                 end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                %                 scAlf=cell(1,ci);
                %                 for i=1:ci%1-CU-e1-q ����ֵ
                %                     scAlf(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                %                 end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='4-K0-lnp-e';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            %%  5.����ѹ��
        case 5%  5-ISO-:lnp-e
            % lnp-e
            figNum=figNum+1;
            figure(figNum);%5-ISO-lnp-e ����ֵ
            ci=0;axes1h = axes();
            for i=istart(ii):eachTestNum(ii)
                ci=ci+1;
                LabDataH(ci)=semilogx((ArrayLabData(i,1:DataLines(i),3)),(ArrayLabData(i,1:DataLines(i),4)),'Marker',marker(ci),'LineStyle',char(linestyle(useL)),'Color',color(ci,:),'LineWidth',1);%
                hold on;
            end
            ci=0;
            for i=istart(ii):eachTestNum(ii)%5-ISO-lnp-e ����ֵ
                ci=ci+1;
                TheoryDataH(ci)=semilogx((ArrayTheoryData(i,1:DataLinesT(i),3)),(ArrayTheoryData(i,1:DataLinesT(i),4)),'Marker','none','LineStyle',char(linestyle(1)),'Color',color(ci,:),'LineWidth',1);
                hold on;
            end
            xlabel('{\itlnp}{''} / kPa','FontWeight','bold');
            ylabel('{\ite}','FontWeight','bold');
            title('{\itISO:}{\itlnp}{''} - {\ite}');% grid on;hold on
            axes1h.Title.Visible=axesTitleVisible;
            %           grid on;hold on  axes1h.XGrid='on';% Ҳ���Կ���
            set(axes1h,'XGrid',XGridOnOff,'YGrid',YGridOnOff);
            
            % ��ǰ�õ��Ĳ��� Χѹ�Ϳ�϶��
            thisTypeSc=sc(istart(ii):eachTestNum(ii));
            thisTypeVoidRatio=iniVoidRatio(istart(ii):eachTestNum(ii));
            %����һ��table��ʵ���ȶԱ�����Χѹ����������Χѹ��ͬ���ٶԿ�϶�Ƚ�������
            tableSCVR = table;%����һ������
            tableSCVR.sc=thisTypeSc';% ������
            tableSCVR.vr=thisTypeVoidRatio';% ������
            [~,scvrIndex]=sortrows(tableSCVR,[1,2],{scSortDirection,iniVoidRatioDirection});%{'ascend','descend'} ,iniVoidRatioDirection���������ǽ���
            % Ȼ��� ��Ӧ�Ŀ�϶�ȡ�����ֵ������ֵ�����ľ�������ƶ�
            LabDataH=LabDataH(scvrIndex);
            TheoryDataH=TheoryDataH(scvrIndex);
            thisTypeSc=thisTypeSc(scvrIndex);
            thisTypeVoidRatio=thisTypeVoidRatio(scvrIndex);
            
            
            if lgdStyle==1
                %scAlf=sprintfc('%g',repmat(sc(istart(ii):eachTestNum(ii)),1,2));%����������ת�����ַ�������
                scAlf=sprintfc('%g',repmat(thisTypeSc,1,2));%����������ת�����ַ�������
                legend(scAlf,'Location','bestoutside');%��ͼ��
                fontModify;%�޸�����
                picName='5-ISO-lnp-e';
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            elseif lgdStyle==2
                scAlf1=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf1(i)=cellstr(string(lgdexperiment));% ����ʾ������
                end
                lgd1=legend(LabDataH,scAlf1,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd1.TextColor='white';%����ʾ��ߵ���
                lgd1.Title.String = lgdLeftTitle;
                lgd1.Title.Color='black';
                lgd1.Title.Visible=lgd1TitleVisibleOnOff;
                lgd1.Visible=legendonoff;
                % set(lgd1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
                lgd1.FontName=FontName;
                lgd1.FontSize=FontSize;
                lgd1.Visible=lgd1Visible;
                axes2h=axes('position',get(gca,'position'),'visible','off');%�½�һ��axes
                scAlf2=cell(1,ci);
                for i=1:ci%1-CU-e1-q ����ֵ
                    scAlf2(i)=cellstr(string(sprintf(formatSpec,thisTypeSc(i),thisTypeVoidRatio(i))));
                end
                lgd2=legend(axes2h,TheoryDataH,scAlf2,'Location',Location,'Box',Boxonoff);%��ͼ��
                lgd2.Title.String = lgdRightTitle;
                % lgd2.Visible=legendonoff;
                lgd2.FontName=FontName;
                lgd2.FontSize=FontSize;
                lgd2.Title.Visible=lgd2TitleVisibleOnOff;
                lgd2.Visible=lgd2Visible;
                fontModify;%�޸�����
                picName='5-ISO-lnp-e';
                pause;print(gcf,printfmttp,fdpi,[picPath picName]);
                saveas(gcf,[picPath picName],formattype); %���浱ǰ���ڵ�ͼ��
            end
            
            
            
            
    end
    
end
fclose('all');%�ر����д򿪵��ı��ĵ�
disp('picture output end!')
%% �Ӻ�������

