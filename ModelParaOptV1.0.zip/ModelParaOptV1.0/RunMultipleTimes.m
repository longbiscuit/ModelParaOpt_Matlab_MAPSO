clc
clear all;
close all;
allRunTimes=200;
for iterofRunTime=1:allRunTimes
    disp(['-------------------------' num2str(iterofRunTime) '-------------------------' ]);
    main_ModelParaOpt_MAPSO
    %csuh
    %If you need to run it more than once, you simply put the results of each run into TXT
    fid=fopen(['G:\Codeing\matlab\OPT\Github\ModelParaOptV0.5\CSUHClayResult\','allResult.txt'],'a');
    fprintf(fid,'%.3f\t %.3f\t %.3f\t %.3f\t %.3f\t %.3f\t %.3f\t %.3f\t %.3f\t %.8f\t %.8f\t \r\n',bestPara(1),bestPara(2),bestPara(3),bestPara(4),bestPara(5),bestPara(6),bestPara(7),bestPara(8),bestPara(9),bestParaError,errorValue);
    fclose(fid);
    pause(1)%��ͣ2s
end
disp('all end~')



