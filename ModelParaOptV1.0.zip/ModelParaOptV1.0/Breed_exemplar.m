%% subfunction
%%%%%%%%%%%%%%%%%%% Ϊĳ����ѡ��ѧϰ���� %%%%%%%%%%%%%%%%%%%%%%%%
function new=Breed_exemplar(elites_pos, elites_val, elites_size, number,pmVar, fes, MaxFEs, lu)
%%

[~, IX]=min(elites_val);
gbest=elites_pos(IX,:);
[N,D]=size(elites_pos);
index=randperm(N);
for i=1:N
    for j=1:N
        if(isequal(elites_pos(i,:),elites_pos(j,:)))
            break;
        end
    end
    
    F=1.0; CR=0.5; pm=0.1;
    %% ................. Mutation ...........................%
    F=1.0; CR=0.5; pm=0.01;
    %         index(1: 3) = floor(rand(1, 3) * elites_size) + 1;
    
    % Choose the indices for mutation
    indexSet = 1 : elites_size;
    indexSet(i) = [];
    
    % Choose the first index
    temp = floor(rand * (elites_size - 1)) + 1;
    index(1) = indexSet(temp);
    indexSet(temp) = [];
    
    % Choose the second index
    temp = floor(rand * (elites_size - 2)) + 1;
    index(2) = indexSet(temp);
    indexSet(temp) = [];
    
    % Choose the third index
    temp = floor(rand * (elites_size - 3)) + 1;
    index(3) = indexSet(temp);
    indexSet(temp) = [];
    
    % Choose the fourth index
    temp = floor(rand * (elites_size - 4)) + 1;
    index(4) = indexSet(temp);
    indexSet(temp) = [];
    
    % Choose the fifth index
    temp = floor(rand * (elites_size - 5)) + 1;
    index(5) = indexSet(temp);
    
    %% "current-to-rand/1" strategy
    %         v2 = elites_pos(i, :) + rand(1,D) .* (elites_pos(index(1), :) - elites_pos(i, :)) +...
    %              rand(1,D) .* (elites_pos(index(2), :) - elites_pos(index(3), :));
    
    %% "rand/1/bin" strategy
    v2 = elites_pos(index(1), :) + F.* (elites_pos(index(2), :) - elites_pos(index(3), :));
    
    %% "rand/2/bin" strategy
    %         v2 = elites_pos(index(1), :) + rand(1,D).* (elites_pos(index(2), :) - elites_pos(index(3), :)) + rand(1,D).* (elites_pos(index(4), :) - elites_pos(index(5), :));
    
    %% "best/1/bin" strategy
    %         v2 = gbest(1, :) + F.* (elites_pos(index(1), :) - elites_pos(index(2), :));
    
    %% "best/2/bin" strategy
    %         v2 = gbest(1, :) + rand .* (elites_pos(index(1), :) - elites_pos(index(2), :)) + F.* (elites_pos(index(3), :) - elites_pos(index(4), :));
    
    %% "current-to-best/1/bin" strategy
    %         v2 = elites_pos(i,:)+F.*(gbest(1, :)-elites_pos(i,:)) + F.* (elites_pos(index(1), :) - elites_pos(index(2), :));
    
    % Handle the elements of the mutant vector which violate the boundary
    vioLow = find(v2 < lu(1, :));
    if ~isempty(vioLow)
        v2(1, vioLow) = 2 .* lu(1, vioLow) - v2(1, vioLow);
        vioLowUpper = find(v2(1, vioLow) > lu(2, vioLow));
        if ~isempty(vioLowUpper)
            v2(1, vioLow(vioLowUpper)) = lu(2, vioLow(vioLowUpper));
        end
    end
    
    vioUpper = find(v2 > lu(2, :));
    if ~isempty(vioUpper)
        v2(1, vioUpper) = 2 .* lu(2, vioUpper) - v2(1, vioUpper);
        vioUpperLow = find(v2(1, vioUpper) < lu(1, vioUpper));
        if ~isempty(vioUpperLow)
            v2(1, vioUpper(vioUpperLow)) = lu(1, vioUpper(vioUpperLow));
        end
    end
    
    % Binomial crossover
    j_rand = floor(rand * D) + 1;
    t = rand(1, D) < CR;%CR(paraIndex);
    t(1, j_rand) = 1;
    t_ = 1 - t;
    new(i,:) = t .* v2 + t_ .* elites_pos(i,:);
    for j=1:D
        if rand<pm
            new(i,j)=lu(1,D)+rand*(lu(2,D)-lu(1,D));
        end
    end
    %                 new(i,:) = v2;
    
end


end